
public class ClusteringCoefficient {

    // Number of vertices N, and degree r
    public static int variableNR[][] = {{10,2}, {10,4}, {25,2}, {25,5}, {25,8}, {50,2}, {50,5}, {50,10}, {50,15}, {100,15}, {100,20}, {100,35}};
    
    // Clustering Coefficient
    public static double[] resultC;
    
	
    public static double clusteringCoefficient(int intN, int intR) 
    {
    	double result;
    	double N = intN;
    	double r = intR;
    	
    	result = 2 * r / ((N/2) * ((N/2) - 1));
   	
    	return result;
    }
    
    public static void main(String[] args) {
		
    	resultC = new double[12];
    	int j = 0;
		
		for (int[] i : variableNR)
		{
			resultC[j] = clusteringCoefficient(i[0],i[1]);
			System.out.println( "N :" + i[0] + " r : " + i[1] + " k : " + 2*i[1] + " C = " + resultC[j] );
			
			j++;
			
		}
	}

}
